import time
import numpy as np
import pandas as pd
import argparse
import glob
import os
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import f1_score, accuracy_score, precision_score, recall_score
import torch
import torch.nn.functional as F
from gcn_model import GCN
from sklearn.model_selection import ParameterGrid


def setup_seed(seed):
    torch.manual_seed(seed)
    np.random.seed(seed)


def accuracy(output, labels):
    pred = output.max(1)[1].type_as(labels)
    correct = pred.eq(labels).double()
    correct = correct.sum()
    return correct / len(labels)


def train(epoch, optimizer, features, adj, labels, idx_train):
    labels.to(device)

    GCN_model.train()
    optimizer.zero_grad()
    output = GCN_model(features, adj)
    loss_train = F.cross_entropy(output[idx_train], labels[idx_train])
    acc_train = accuracy(output[idx_train], labels[idx_train])
    loss_train.backward()
    optimizer.step()
    if (epoch + 1) % 10 == 0:
        print('Epoch: %.2f | loss train: %.4f | acc train: %.4f' % (epoch + 1, loss_train.item(), acc_train.item()))
    return loss_train.data.item()


def test(features, adj, labels, idx_test):
    GCN_model.eval()
    output = GCN_model(features, adj)
    loss_test = F.cross_entropy(output[idx_test], labels[idx_test])

    # Get predicted labels (one-hot to digit)
    pred_labels = output[idx_test].detach().cpu().numpy()
    pred_labels = np.argmax(pred_labels, axis=1)

    # Get true labels
    true_labels = labels[idx_test].detach().cpu().numpy()

    # Calculate metrics
    acc = accuracy_score(true_labels, pred_labels) * 100  # Accuracy (%)
    f1 = f1_score(true_labels, pred_labels, average='weighted') * 100  # F1-score (%)
    precision = precision_score(true_labels, pred_labels, average='weighted') * 100  # Precision (%)
    recall = recall_score(true_labels, pred_labels, average='weighted') * 100  # Recall (%)

    # Print results
    print("\nTest set results:",
          "loss= {:.4f}".format(loss_test.item()),
          "Accuracy= {:.2f}%".format(acc),
          "F1= {:.2f}%".format(f1),
          "Precision= {:.2f}%".format(precision),
          "Recall= {:.2f}%".format(recall))

    return {
        "accuracy": acc,
        "f1_score": f1,
        "precision": precision,
        "recall": recall,
        "true_labels": true_labels,
        "pred_labels": pred_labels
    }


def predict(features, adj, sample, idx):
    GCN_model.eval()
    output = GCN_model(features, adj)
    predict_label = output.detach().cpu().numpy()
    predict_label = np.argmax(predict_label, axis=1).tolist()

    true_labels = labels[idx].detach().cpu().numpy()
    res_data = pd.DataFrame({
        '真实标签': true_labels,
        '预测标签': predict_label
    })
    res_data = res_data.iloc[idx, :]
    res_data.to_csv('data/data2/GCN_predicted_data.csv', header=True, index=False)
    print(f"预测结果已保存")


def load_data(adj, fea, lab, threshold=0.005):
    print('loading data...')
    adj_df = pd.read_csv(adj, header=0, index_col=None)
    fea_df = pd.read_csv(fea, header=0, index_col=None)
    label_df = pd.read_csv(lab, header=0, index_col=None)

    if adj_df.shape[0] != fea_df.shape[0] or adj_df.shape[0] != label_df.shape[0]:
        print('Input files must have same samples.')
        exit(1)

    adj_df.rename(columns={adj_df.columns.tolist()[0]: 'Sample'}, inplace=True)
    fea_df.rename(columns={fea_df.columns.tolist()[0]: 'Sample'}, inplace=True)
    label_df.rename(columns={label_df.columns.tolist()[0]: 'Sample'}, inplace=True)

    adj_df.sort_values(by='Sample', ascending=True, inplace=True)
    fea_df.sort_values(by='Sample', ascending=True, inplace=True)
    label_df.sort_values(by='Sample', ascending=True, inplace=True)

    print('Calculating the laplace adjacency matrix...')
    adj_m = adj_df.iloc[:, 1:].values
    adj_m[adj_m < threshold] = 0

    exist = (adj_m != 0) * 1.0
    factor = np.ones(adj_m.shape[1])
    res = np.dot(exist, factor)
    diag_matrix = np.diag(res)

    d_inv = np.linalg.inv(diag_matrix)
    adj_hat = d_inv.dot(exist)

    return adj_hat, fea_df, label_df


def setup_grid_search():
    param_grid = {
        'hidden': [64, 128, 256],
        'dropout': [0.3, 0.5, 0.7],
        'lr': [0.001, 0.005, 0.01],
        'weight_decay': [0.0001, 0.0005, 0.001]
    }
    return list(ParameterGrid(param_grid))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--featuredata', '-fd', type=str, required=True, help='The vector feature file.')
    parser.add_argument('--adjdata', '-ad', type=str, required=True, help='The adjacency matrix file.')
    parser.add_argument('--labeldata', '-ld', type=str, required=True, help='The sample label file.')
    parser.add_argument('--testsample', '-ts', type=str, help='Test sample names file.')
    parser.add_argument('--mode', '-m', type=int, choices=[0,1], default=0, help='mode 0: 10-fold cross validation; mode 1: train and test a model.')
    parser.add_argument('--seed', '-s', type=int, default=0, help='Random seed, default=0.')
    parser.add_argument('--device', '-d', type=str, choices=['cpu', 'gpu'], default='cpu', help='Training on cpu or gpu, default: cpu.')
    parser.add_argument('--epochs', '-e', type=int, default=150, help='Training epochs, default: 150.')
    parser.add_argument('--learningrate', '-lr', type=float, default=0.001, help='Learning rate, default: 0.001.')
    parser.add_argument('--weight_decay', '-w', type=float, default=0.01, help='Weight decay (L2 loss on parameters), methods to avoid overfitting, default: 0.01')
    parser.add_argument('--hidden', '-hd',type=int, default=64, help='Hidden layer dimension, default: 64.')
    parser.add_argument('--dropout', '-dp', type=float, default=0., help='Dropout rate, methods to avoid overfitting, default: 0.5.')
    parser.add_argument('--threshold', '-t', type=float, default=0.005, help='Threshold to filter edges, default: 0.005')
    parser.add_argument('--nclass', '-nc', type=int, default=22, help='Number of classes, default: 20')
    parser.add_argument('--patience', '-p', type=int, default=20, help='Patience')
    args = parser.parse_args()

    device = torch.device('cpu')
    if args.device == 'gpu':
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    setup_seed(args.seed)

    adj, data, label = load_data(args.adjdata, args.featuredata, args.labeldata, args.threshold)

    start_time = time.time()

    adj = torch.tensor(adj, dtype=torch.float, device=device)
    features = torch.tensor(data.iloc[:, 1:].values, dtype=torch.float, device=device)
    labels = torch.tensor(label.iloc[:, 1].values, dtype=torch.long, device=device)

    print("标签总数:", len(labels))
    print("标签类别数:", len(torch.unique(labels)))
    print('Begin training model...')

    if args.mode == 0:
        skf = StratifiedKFold(n_splits=10, shuffle=True)

        acc_res, f1_res, precision_res, recall_res = [], [], [], []
        hyperparameter_results = []

        param_grid = setup_grid_search()

        fold_num = 1
        for params in param_grid:
            print(f"\nTraining with parameters: {params}")

            acc_fold, f1_fold, precision_fold, recall_fold = [], [], [], []

            for idx_train, idx_test in skf.split(data.iloc[:, 1:], label.iloc[:, 1]):
                GCN_model = GCN(n_in=features.shape[1], n_hid=params['hidden'], n_out=args.nclass, dropout=params['dropout'])
                GCN_model.to(device)

                optimizer = torch.optim.Adam(GCN_model.parameters(), lr=params['lr'], weight_decay=params['weight_decay'])

                idx_train = torch.tensor(idx_train, dtype=torch.long, device=device)
                idx_test = torch.tensor(idx_test, dtype=torch.long, device=device)

                for epoch in range(args.epochs):
                    train(epoch, optimizer, features, adj, labels, idx_train)

                test_results = test(features, adj, labels, idx_test)

                acc_fold.append(test_results["accuracy"])
                f1_fold.append(test_results["f1_score"])
                precision_fold.append(test_results["precision"])
                recall_fold.append(test_results["recall"])

            mean_acc = np.mean(acc_fold)
            mean_f1 = np.mean(f1_fold)

            print(f"Mean ACC: {mean_acc:.2f}%")
            print(f"Mean F1: {mean_f1:.2f}%")

            hyperparameter_results.append({
                'hidden': params['hidden'],
                'dropout': params['dropout'],
                'lr': params['lr'],
                'weight_decay': params['weight_decay'],
                'ACC': mean_acc,
                'weighted_F1': mean_f1
            })

        hyperparameter_df = pd.DataFrame(hyperparameter_results)
        hyperparameter_df.to_csv("hyperparameter_search_results.csv", index=False)
        print("Hyperparameter search results saved!")

    end_time = time.time()
    total_time = end_time - start_time
    print('Finished!')
    print(f"总运行时间: {total_time:.2f} 秒")
