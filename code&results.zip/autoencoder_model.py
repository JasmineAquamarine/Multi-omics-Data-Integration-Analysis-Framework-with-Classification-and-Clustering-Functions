#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2021/8/7 14:01
# @Author  : Li Xiao
# @File    : autoencoder_model.py
import numpy as np
import torch
from torch import nn
from matplotlib import pyplot as plt


class Attention(nn.Module):
    def __init__(self, nz):
        super(Attention, self).__init__()
        self.query = nn.Linear(nz, nz)
        self.key = nn.Linear(nz, nz)
        self.value = nn.Linear(nz, nz)
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x1, x2):
        q = self.query(x1).unsqueeze(2)
        k = self.key(x2).unsqueeze(1)
        v = self.value(x2)

        attention_scores = torch.bmm(q, k) / np.sqrt(x1.size(1))
        attention_weights = self.softmax(attention_scores)
        attn_out = torch.bmm(attention_weights, v.unsqueeze(2)).squeeze(2)
        return attn_out


class MMAE(nn.Module):
    def __init__(self, in_feas_dim, latent_dim, a=0.6, b=0.4):
        '''
        :param in_feas_dim: a list, input dims of omics data
        :param latent_dim: dim of latent layer
        :param a: weight of omics data type 1
        :param b: weight of omics data type 2
        :param c: weight of omics data type 3
        in_feas_dim：输入特征的维度，是一个列表，包含三个组学数据类型的特征数量。
        latent_dim：潜在层的维度。
        a、b、c：三个组学的权重
        '''
        super(MMAE, self).__init__()
        self.a = a
        self.b = b
        #self.c = c
        self.in_feas = in_feas_dim
        self.latent = latent_dim

        self.attention = Attention(self.latent)
        #编码器，多通道输入
        self.encoder_omics_1 = nn.Sequential(
            nn.Linear(self.in_feas[0], self.latent),
            nn.BatchNorm1d(self.latent),
            nn.Sigmoid()
        )
        self.encoder_omics_2 = nn.Sequential(
            nn.Linear(self.in_feas[1], self.latent),
            nn.BatchNorm1d(self.latent),
            nn.Sigmoid()
        )

        #解码器
        self.decoder_omics_1 = nn.Sequential(nn.Linear(self.latent, self.in_feas[0]))
        self.decoder_omics_2 = nn.Sequential(nn.Linear(self.latent, self.in_feas[1]))
        #self.decoder_omics_3 = nn.Sequential(nn.Linear(self.latent, self.in_feas[2]))

        #变量初始化
        for name, param in MMAE.named_parameters(self):
            if 'weight' in name:
                torch.nn.init.normal_(param, mean=0, std=0.1)
            if 'bias' in name:
                torch.nn.init.constant_(param, val=0)

    def forward(self, omics_1, omics_2):
        '''
        :param omics_1: omics data 1
        :param omics_2: omics data 2
        :param omics_3: omics data 3
        '''
        encoded_omics_1 = self.encoder_omics_1(omics_1)
        encoded_omics_2 = self.encoder_omics_2(omics_2)

        attn_out = self.attention(encoded_omics_1, encoded_omics_2)
        latent_data = attn_out + 0.1 * (encoded_omics_1 + encoded_omics_2)

        decoded_omics_1 = self.decoder_omics_1(latent_data)
        decoded_omics_2 = self.decoder_omics_2(latent_data)
        #decoded_omics_3 = self.decoder_omics_3(latent_data)
        return latent_data, decoded_omics_1, decoded_omics_2

    def train_MMAE(self, train_loader, learning_rate=0.001, device=torch.device('cpu'), epochs=100):
        optimizer = torch.optim.Adam(self.parameters(), lr=learning_rate)
        loss_fn = nn.MSELoss()
        loss_ls = []
        for epoch in range(epochs):
            train_loss_sum = 0.0       #Record the loss of each epoch
            for (x,y) in train_loader:
                omics_1 = x[:, :self.in_feas[0]]
                omics_2 = x[:, self.in_feas[0]:self.in_feas[0]+self.in_feas[1]]
                #omics_3 = x[:, self.in_feas[0]+self.in_feas[1]:self.in_feas[0]+self.in_feas[1]+self.in_feas[2]]

                omics_1 = omics_1.to(device)
                omics_2 = omics_2.to(device)
                #omics_3 = omics_3.to(device)

                latent_data, decoded_omics_1, decoded_omics_2= self.forward(omics_1, omics_2)
                loss = self.a*loss_fn(decoded_omics_1, omics_1)+ self.b*loss_fn(decoded_omics_2, omics_2)
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

                train_loss_sum += loss.sum().item()

            loss_ls.append(train_loss_sum)
            print('epoch: %d | loss: %.4f' % (epoch + 1, train_loss_sum))

            #save the model every 10 epochs, used for feature extraction
            if (epoch+1) % 10 ==0:
                torch.save(self, 'model/AE/model_{}.pkl'.format(epoch+1))

